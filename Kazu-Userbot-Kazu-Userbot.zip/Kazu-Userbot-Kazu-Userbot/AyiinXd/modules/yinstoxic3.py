# Ayiin - Userbot
# Copyright (C) 2022-2023 @AyiinXd
#
# This file is a part of < https://github.com/AyiinXd/Ayiin-Userbot/ >
# PLease read the GNU Affero General Public License in
# <https://www.github.com/AyiinXd/Ayiin-Userbot/blob/main/LICENSE/>.
#
# FROM Ayiin-Userbot <https://github.com/AyiinXd/Ayiin-Userbot>
# t.me/AyiinXdSupport & t.me/AyiinSupport


# ========================×========================
#            Jangan Hapus Credit Ngentod
# ========================×========================


from time import sleep

from AyiinXd import CMD_HANDLER as cmd
from AyiinXd import CMD_HELP
from AyiinXd.ayiin import ayiin_cmd, eor
from Stringyins import get_string


@ayiin_cmd(pattern="ceking(?: |$)(.*)")
async def _(mnghna):
    Ayiin = await mnghneor(a, get_string("yitxc_74"))
    sleep(1)
    await Ayiin.edit(get_string("yitxc_75"))
    sleep(1)
    await Ayiin.edit(get_string("yitxc_76"))
    sleep(1)
    await Ayiin.edit(get_string("yitxc_77"))
    sleep(1.5)
    await Ayiin.edit(get_string("yitxc_78"))
    sleep(1.5)
    await Ayiin.edit(get_string("yitxc_79"))
    sleep(1)
    await Ayiin.edit(get_string("yitxc_80"))


@ayiin_cmd(pattern="hina(?: |$)(.*)")
async def _(war):
    Xd = await eor(war, get_string("yitxc_81"))
    sleep(1.5)
    await Xd.edit(get_string("yitxc_82"))
    sleep(1)
    await Xd.edit(get_string("yitxc_83"))
    sleep(1)
    await Xd.edit(get_string("yitxc_84"))
    sleep(1.5)
    await Xd.edit(get_string("yitxc_85"))
    sleep(1)
    await Xd.edit(get_string("yitxc_86"))
    sleep(1.5)
    await Xd.edit(get_string("yitxc_87"))
    sleep(1)
    await Xd.edit(get_string("yitxc_88"))
    sleep(1)
    await Xd.edit(get_string("yitxc_89"))


@ayiin_cmd(pattern="ngaca(?: |$)(.*)")
async def _(mikir):
    Yins = await eor(mikir, get_string("yitxc_90"))
    sleep(1.5)
    await Yins.edit(get_string("yitxc_91"))
    sleep(1)
    await Yins.edit(get_string("yitxc_92"))
    sleep(1)
    await Yins.edit(get_string("yitxc_93"))
    sleep(1)
    await Yins.edit(get_string("yitxc_94"))
    sleep(1.5)
    await Yins.edit(get_string("yitxc_95"))
    sleep(1.5)
    await Yins.edit(get_string("yitxc_96"))


# ========================×========================
#            Jangan Hapus Credit Ngentod
# ========================×========================


CMD_HELP.update(
    {
        "yinstoxic3": f"**Plugin : **`yinstoxic3`\
        \n\n  »  **Perintah :** `{cmd}ceking`\
        \n  »  **Kegunaan : **Cobain Sendiri Dah Tod.\
        \n\n  »  **Perintah :** `{cmd}hina`\
        \n  »  **Kegunaan : **Cobain Sendiri Dah Tod.\
        \n\n  »  **Perintah :** `{cmd}ngaca`\
        \n  »  **Kegunaan : **Cobain Sendiri Dah Tod.\
    "
    }
)
