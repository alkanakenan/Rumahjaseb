from .strings import get_languages, get_string, language
from bs4 import BeautifulSoup
